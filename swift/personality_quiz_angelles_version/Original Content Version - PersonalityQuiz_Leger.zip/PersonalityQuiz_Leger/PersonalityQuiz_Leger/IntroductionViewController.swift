//
//  ViewController.swift
//  PersonalityQuiz_Leger
//
//  Created by Angelle Leger on 2/16/24.
//

import UIKit

class IntroductionViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue){
        
    }
}

