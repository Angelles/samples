//
//  Question.swift
//  PersonalityQuiz_Leger
//
//  Created by Angelle Leger on 2/17/24.
//

import Foundation

struct Question {
    var text: String
    var type: ResponseType
    var answers: [Answer]
}

enum ResponseType {
    case single, multiple, ranged // different response types available in the quiz
}

struct Answer {
    var text: String
    var type: AnimalType
}

enum AnimalType: Character {
    case dog = "🐶", cat = "🐱", rabbit = "🐰", turtle = "🐢"
    var definition: String {
        switch self {
        case .dog:
            return "You are outgoing and friendly. For you, a good time involves getting outside, getting active, and maybe throwing some steaks on the grill at the park."
        case .cat:
            return "You are elegant and are particular about who you choose to let in your circle. For you, a good time involves a spa day, a nap, and expensive treats."
        case .rabbit:
            return "You are observant and tend to fly under the radar. For you, a good time involves gardening or quiet indoor activities with your friends. You love a big salad."
        case .turtle:
            return "You are enigmatic. No one can get past your shell to get to know you better. For you, a good time would be kayaking on a pond with no one around."
        }
    }
}

